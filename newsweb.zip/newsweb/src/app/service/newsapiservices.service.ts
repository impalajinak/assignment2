import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';



@Injectable({
  providedIn: 'root'
})
export class NewsapiservicesService {

  constructor(private _http:HttpClient) { }

//newsapiurl
newsApiUrl = "https://newsapi.org/v2/top-headlines?country=my&apiKey=64620b5247a844bab997ba1a8aaf2531"

//technewsapiurl
techApiUrl = "https://newsapi.org/v2/top-headlines?country=my&category=technology&apiKey=64620b5247a844bab997ba1a8aaf2531"

//businessnewsapiurl
businessApiUrl = "https://newsapi.org/v2/top-headlines?country=my&category=business&apiKey=64620b5247a844bab997ba1a8aaf2531"


//topheading ()
topHeading():Observable<any>
{
  return this._http.get(this.newsApiUrl);
}

//technews ()
techNews():Observable<any>
{
  return this._http.get(this.techApiUrl);
}

//businessNews ()
businessNews():Observable<any>
{
  return this._http.get(this.businessApiUrl); 
}


}
